﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace EvvMobile.Views.Dashboard
{
    public partial class DashboardPage : ContentPage
    {
        public DashboardPage()
        {
            InitializeComponent();
        }
    }
}
