﻿using System;
namespace EvvMobile.ViewModels.Login
{
    public class LoginViewModel
    {
        public LoginViewModel()
        {

        }
    }
}
