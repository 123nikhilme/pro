﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace EvvMobile.Themes
{
    public partial class DarkTheme : ResourceDictionary
    {
        public DarkTheme()
        {
            InitializeComponent();
        }
    }
}
