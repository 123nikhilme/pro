﻿using System;
namespace EvvMobile
{
    public enum Theme
    {
        Light,
        Dark
    }
}
