﻿namespace MediaManager.Playback
{
    public enum RepeatMode
    {
        Off = 0,
        One = 1,
        All = 2
    }
}
