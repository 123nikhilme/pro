﻿namespace MediaManager.Video
{
    public enum VideoAspectMode
    {
        None,
        AspectFit,
        AspectFill
    }
}
