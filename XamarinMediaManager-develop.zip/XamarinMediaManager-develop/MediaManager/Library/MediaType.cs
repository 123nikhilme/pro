﻿namespace MediaManager.Library
{
    public enum MediaType
    {
        Default,
        Audio,
        Video,
        Dash,
        Hls,
        SmoothStreaming,
        Image
    }
}
