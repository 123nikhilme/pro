﻿namespace MediaManager.Library
{
    public enum SharingType
    {
        Public,
        Protected,
        Private
    }
}
