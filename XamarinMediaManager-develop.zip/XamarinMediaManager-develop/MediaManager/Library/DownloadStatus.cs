﻿namespace MediaManager.Library
{
    public enum DownloadStatus
    {
        Unknown = 0,
        NotDownloaded = 1,
        Downloading = 2,
        Downloaded = 3
    }
}
