﻿namespace MediaManager.Queue
{
    public enum ShuffleMode
    {
        Off = 0,
        All = 1
    }
}
