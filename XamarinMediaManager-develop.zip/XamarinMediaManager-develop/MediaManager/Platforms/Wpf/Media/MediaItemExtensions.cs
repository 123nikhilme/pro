﻿using MediaManager.Library;

namespace MediaManager.Platforms.Wpf.Media
{
    public static class MediaItemExtensions
    {
        public static object ToMediaSource(this IMediaItem mediaItem)
        {
            return null;
        }
    }
}
