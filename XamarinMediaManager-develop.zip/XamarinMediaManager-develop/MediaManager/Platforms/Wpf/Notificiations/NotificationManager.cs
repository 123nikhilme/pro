﻿using MediaManager.Notifications;

namespace MediaManager.Platforms.Wpf.Notificiations
{
    public class NotificationManager : NotificationManagerBase
    {
        public NotificationManager()
        {
        }

        public override void UpdateNotification()
        {
        }
    }
}
