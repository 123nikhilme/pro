﻿using MediaManager.Notifications;

namespace MediaManager.Platforms.Tizen.Notifications
{
    public class NotificationManager : NotificationManagerBase
    {
        public NotificationManager()
        {
        }

        public override void UpdateNotification()
        {

        }
    }
}
