﻿using MediaManager.Notifications;

namespace MediaManager.Platforms.Uap.Notifications
{
    public class NotificationManager : NotificationManagerBase
    {
        public override void UpdateNotification()
        {

        }
    }
}
