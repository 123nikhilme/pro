﻿namespace MediaManager.Media
{
    public interface IMediaExtractorProvider
    {
        bool Enabled { get; set; }
    }
}
