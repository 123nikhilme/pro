﻿using MediaManager.Library;

namespace MediaManager.Media
{
    public interface IPlaylistProvider : ILibraryProvider<IPlaylist>
    {
    }
}
