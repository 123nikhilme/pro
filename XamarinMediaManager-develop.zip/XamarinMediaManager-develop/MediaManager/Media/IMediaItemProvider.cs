﻿using MediaManager.Library;

namespace MediaManager.Media
{
    public interface IMediaItemProvider : ILibraryProvider<IMediaItem>
    {
    }
}
