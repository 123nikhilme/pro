﻿using MediaManager.Library;

namespace MediaManager.Media
{
    public interface IRadioProvider : ILibraryProvider<IRadio>
    {
    }
}
