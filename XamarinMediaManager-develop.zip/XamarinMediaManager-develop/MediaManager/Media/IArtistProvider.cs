﻿using MediaManager.Library;

namespace MediaManager.Media
{
    public interface IArtistProvider : ILibraryProvider<IArtist>
    {
    }
}
