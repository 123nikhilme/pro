﻿using MediaManager;
using MvvmCross.Forms.Platforms.Wpf.Views;

namespace ElementPlayer.Forms.Wpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : MvxFormsWindowsPage
    {
        public MainWindow()
        {
            InitializeComponent();
            CrossMediaManager.Current.Init();
        }
    }
}
