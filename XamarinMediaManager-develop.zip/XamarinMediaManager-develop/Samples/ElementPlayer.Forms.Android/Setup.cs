﻿using MvvmCross.Forms.Platforms.Android.Core;

namespace ElementPlayer.Forms.Droid
{
    public class Setup : MvxFormsAndroidSetup<Core.App, FormsApp>
    {
    }
}
