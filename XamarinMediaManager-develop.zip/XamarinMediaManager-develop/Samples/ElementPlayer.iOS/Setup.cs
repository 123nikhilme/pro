﻿using ElementPlayer.Core;
using MvvmCross.Platforms.Ios.Core;

namespace ElementPlayer.iOS
{
    public class Setup : MvxIosSetup<App>
    {
    }
}
