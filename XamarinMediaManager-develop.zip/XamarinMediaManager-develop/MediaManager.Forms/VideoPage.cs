﻿using Xamarin.Forms;

namespace MediaManager.Forms
{
    public class VideoPage : ContentPage
    {
        public VideoPage()
        {
            this.Content = new VideoView();
        }
    }
}
