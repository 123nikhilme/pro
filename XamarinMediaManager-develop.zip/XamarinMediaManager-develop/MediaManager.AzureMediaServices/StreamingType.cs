﻿namespace MediaManager.AzureMediaServices
{
    public enum StreamingType
    {
        MPEGDash,
        HLSv3,
        HLSv4
    }
}
