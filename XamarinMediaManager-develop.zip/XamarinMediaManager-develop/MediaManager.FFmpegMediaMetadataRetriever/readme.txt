---------------------------------
MediaManager extension for FFmpegMediaMetadataRetriever
---------------------------------



---------------------------------
Star on Github if this project helps you: https://github.com/martijn00/XamarinMediaManager

Commercial support is available. Integration with your app or services, samples, feature request, etc. Email: hello@baseflow.com
Powered by: https://baseflow.com
---------------------------------