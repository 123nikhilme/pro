﻿using Xunit;

namespace MediaManager.UnitTest.Queue
{
    public class MediaQueueTests
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
