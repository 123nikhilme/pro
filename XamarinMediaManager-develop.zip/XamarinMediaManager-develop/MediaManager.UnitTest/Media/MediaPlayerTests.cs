﻿using Xunit;

namespace MediaManager.UnitTest.Media
{
    public class MediaPlayerTests
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
