﻿using Xunit;

namespace MediaManager.UnitTest.Media
{
    public class MediaItemTests
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
