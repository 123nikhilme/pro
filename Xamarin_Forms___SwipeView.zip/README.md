---
name: Xamarin.Forms - SwipeView
description: "This sample demonstrates how to use the Xamarin.Forms SwipeView (UI)"
page_type: sample
languages:
- csharp
products:
- xamarin
extensions:
    tags:
    - ui
urlFragment: userinterface-swipeviewdemos
---
# SwipeView

This sample demonstrates how to use the Xamarin.Forms `SwipeView`.

For more information about this sample, see [Xamarin.Forms SwipeView](https://docs.microsoft.com/xamarin/xamarin-forms/user-interface/swipeview/).

![SwipeView application screenshot](Screenshots/01All.png "SwipeView application screenshot")

