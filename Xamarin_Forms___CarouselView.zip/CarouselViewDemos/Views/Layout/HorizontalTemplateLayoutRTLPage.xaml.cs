﻿using Xamarin.Forms;

namespace CarouselViewDemos.Views
{
    public partial class HorizontalTemplateLayoutRTLPage : ContentPage
    {
        public HorizontalTemplateLayoutRTLPage()
        {
            InitializeComponent();
        }
    }
}
