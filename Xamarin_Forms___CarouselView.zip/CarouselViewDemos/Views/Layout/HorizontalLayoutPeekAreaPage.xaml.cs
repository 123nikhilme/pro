﻿using Xamarin.Forms;

namespace CarouselViewDemos.Views
{
    public partial class HorizontalLayoutPeekAreaPage : ContentPage
    {
        public HorizontalLayoutPeekAreaPage()
        {
            InitializeComponent();
        }
    }
}
