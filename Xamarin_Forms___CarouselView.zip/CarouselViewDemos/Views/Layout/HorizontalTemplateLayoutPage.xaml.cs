﻿using Xamarin.Forms;

namespace CarouselViewDemos.Views
{
    public partial class HorizontalTemplateLayoutPage : ContentPage
    {
        public HorizontalTemplateLayoutPage()
        {
            InitializeComponent();            
        }
    }
}
