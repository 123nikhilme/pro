﻿using Xamarin.Forms;

namespace CarouselViewDemos.Views
{
    public partial class HorizontalTextLayoutPage : ContentPage
    {
        public HorizontalTextLayoutPage()
        {
            InitializeComponent();
        }
    }
}
