﻿using Xamarin.Forms;

namespace CarouselViewDemos.Views
{
    public partial class VerticalTextLayoutPage : ContentPage
    {
        public VerticalTextLayoutPage()
        {
            InitializeComponent();
        }
    }
}
