﻿using Xamarin.Forms;

namespace CarouselViewDemos.Views
{
    public partial class HorizontalLayoutDataTemplateSelectorPage : ContentPage
    {
        public HorizontalLayoutDataTemplateSelectorPage()
        {
            InitializeComponent();
        }
    }
}
