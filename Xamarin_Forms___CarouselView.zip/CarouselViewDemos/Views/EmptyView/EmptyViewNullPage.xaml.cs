﻿using Xamarin.Forms;

namespace CarouselViewDemos.Views
{
    public partial class EmptyViewNullPage : ContentPage
    {
        public EmptyViewNullPage()
        {
            InitializeComponent();
        }
    }
}
