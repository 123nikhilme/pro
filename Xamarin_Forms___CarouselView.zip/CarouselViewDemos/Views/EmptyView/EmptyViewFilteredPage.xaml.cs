﻿using Xamarin.Forms;

namespace CarouselViewDemos.Views
{
    public partial class EmptyViewFilteredPage : ContentPage
    {
        public EmptyViewFilteredPage()
        {
            InitializeComponent();
        }
    }
}
