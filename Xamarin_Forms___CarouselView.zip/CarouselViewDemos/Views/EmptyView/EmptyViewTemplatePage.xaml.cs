﻿using Xamarin.Forms;

namespace CarouselViewDemos.Views
{
    public partial class EmptyViewTemplatePage : ContentPage
    {
        public EmptyViewTemplatePage()
        {
            InitializeComponent();
        }
    }
}
