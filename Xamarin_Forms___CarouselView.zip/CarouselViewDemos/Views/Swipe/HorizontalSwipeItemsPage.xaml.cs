﻿using Xamarin.Forms;

namespace CarouselViewDemos.Views
{
    public partial class HorizontalSwipeItemsPage : ContentPage
    {
        public HorizontalSwipeItemsPage()
        {
            InitializeComponent();
        }
    }
}
