﻿using Xamarin.Forms;

namespace CarouselViewDemos.Views
{
    public partial class HorizontalLayoutWithIndicatorsPage : ContentPage
    {
        public HorizontalLayoutWithIndicatorsPage()
        {
            InitializeComponent();
        }
    }
}
