﻿using Xamarin.Forms;

namespace CarouselViewDemos.Views
{
    public partial class CurrentItemAndPositionBindingsPage : ContentPage
    {
        public CurrentItemAndPositionBindingsPage()
        {
            InitializeComponent();
        }
    }
}
