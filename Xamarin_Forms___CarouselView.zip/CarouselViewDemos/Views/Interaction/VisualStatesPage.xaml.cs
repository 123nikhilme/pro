﻿using Xamarin.Forms;

namespace CarouselViewDemos.Views
{
    public partial class VisualStatesPage : ContentPage
    {
        public VisualStatesPage()
        {
            InitializeComponent();
        }
    }
}
