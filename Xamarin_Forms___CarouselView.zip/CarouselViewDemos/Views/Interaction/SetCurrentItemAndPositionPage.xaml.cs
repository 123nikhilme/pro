﻿using Xamarin.Forms;

namespace CarouselViewDemos.Views
{
    public partial class SetCurrentItemAndPositionPage : ContentPage
    {
        public SetCurrentItemAndPositionPage()
        {
            InitializeComponent();
        }
    }
}
