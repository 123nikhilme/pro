﻿using Xamarin.Forms;

namespace CarouselViewDemos.Views
{
    public partial class VerticalSpacingPage : ContentPage
    {
        public VerticalSpacingPage()
        {
            InitializeComponent();
        }
    }
}
