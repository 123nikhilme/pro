﻿using Xamarin.Forms;

namespace CarouselViewDemos.Views
{
    public partial class HorizontalSpacingPage : ContentPage
    {
        public HorizontalSpacingPage()
        {
            InitializeComponent();
        }
    }
}
