﻿using Xamarin.Forms;

namespace CarouselViewDemos.Views
{
    public partial class VerticalPullToRefreshPage : ContentPage
    {
        public VerticalPullToRefreshPage()
        {
            InitializeComponent();
        }
    }
}
