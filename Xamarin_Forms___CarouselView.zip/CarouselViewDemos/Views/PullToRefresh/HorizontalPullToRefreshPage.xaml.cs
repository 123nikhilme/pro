﻿using Xamarin.Forms;

namespace CarouselViewDemos.Views
{
    public partial class HorizontalPullToRefreshPage : ContentPage
    {
        public HorizontalPullToRefreshPage()
        {
            InitializeComponent();
        }
    }
}
