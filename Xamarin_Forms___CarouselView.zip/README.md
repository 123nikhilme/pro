---
name: Xamarin.Forms - CarouselView
description: "This sample demonstrates how to use the Xamarin.Forms CarouselView (UI)"
page_type: sample
languages:
- csharp
products:
- xamarin
extensions:
    tags:
    - ui
urlFragment: userinterface-carouselviewdemos
---
# CarouselView

This sample demonstrates how to use the Xamarin.Forms `CarouselView`.

For more information about this sample, see [Xamarin.Forms CarouselView](https://docs.microsoft.com/xamarin/xamarin-forms/user-interface/carouselview/).

![CarouselView application screenshot](Screenshots/01All.png "CarouselView application screenshot")

