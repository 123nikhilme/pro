---
name: Xamarin.Forms - Expander Demos
description: "This sample demonstrates how to use a Xamarin.Forms Expander (UI)"
page_type: sample
languages:
- csharp
products:
- xamarin
extensions:
    tags:
    - ui
urlFragment: userinterface-expanderdemos
---
# Expander Demos

This sample demonstrates how to use a Xamarin.Forms `Expander`.

For more information about this sample, see [Xamarin.Forms Expander](https://docs.microsoft.com/xamarin/xamarin-forms/user-interface/expander).

![Expander Demos application screenshot](Screenshots/01All.png "Expander Demos application screenshot")
