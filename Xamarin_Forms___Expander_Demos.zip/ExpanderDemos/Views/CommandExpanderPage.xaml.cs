﻿using Xamarin.Forms;

namespace ExpanderDemos.Views
{
    public partial class CommandExpanderPage : ContentPage
    {
        public CommandExpanderPage()
        {
            InitializeComponent();
        }
    }
}
