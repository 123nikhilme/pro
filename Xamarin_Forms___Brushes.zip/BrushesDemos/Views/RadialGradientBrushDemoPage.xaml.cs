﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace BrushesDemos.Views
{
    public partial class RadialGradientBrushDemoPage : ContentPage
    {
        public RadialGradientBrushDemoPage()
        {
            InitializeComponent();
        }
    }
}
