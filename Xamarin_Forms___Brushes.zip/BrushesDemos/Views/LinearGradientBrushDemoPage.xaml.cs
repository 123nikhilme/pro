﻿using Xamarin.Forms;

namespace BrushesDemos.Views
{
    public partial class LinearGradientBrushDemoPage : ContentPage
    {
        public LinearGradientBrushDemoPage()
        {
            InitializeComponent();
        }
    }
}
