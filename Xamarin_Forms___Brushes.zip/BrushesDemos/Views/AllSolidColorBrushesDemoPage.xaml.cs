﻿using Xamarin.Forms;

namespace BrushesDemos.Views
{
    public partial class AllSolidColorBrushesDemoPage : ContentPage
    {
        public AllSolidColorBrushesDemoPage()
        {
            InitializeComponent();
        }
    }
}
