﻿using Xamarin.Forms;

namespace BrushesDemos.Views
{
    public partial class SolidColorBrushDemoPage : ContentPage
    {
        public SolidColorBrushDemoPage()
        {
            InitializeComponent();
        }
    }
}
