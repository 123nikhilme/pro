﻿using Xamarin.Forms;

namespace BrushesDemos.Views
{
    public partial class CSSDemoPage : ContentPage
    {
        public CSSDemoPage()
        {
            InitializeComponent();
        }
    }
}
