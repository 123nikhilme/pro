﻿using Xamarin.Forms;

namespace ShapesDemos
{
    public partial class PolygonDemoPage : ContentPage
    {
        public PolygonDemoPage()
        {
            InitializeComponent();
        }
    }
}
