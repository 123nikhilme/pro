﻿using Xamarin.Forms;

namespace ShapesDemos
{
    public partial class BrushesDemoPage : ContentPage
    {
        public BrushesDemoPage()
        {
            InitializeComponent();
        }
    }
}
