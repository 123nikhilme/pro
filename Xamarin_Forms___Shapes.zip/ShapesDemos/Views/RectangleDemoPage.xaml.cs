﻿using Xamarin.Forms;

namespace ShapesDemos
{
    public partial class RectangleDemoPage : ContentPage
    {
        public RectangleDemoPage()
        {
            InitializeComponent();
        }
    }
}
