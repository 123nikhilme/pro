﻿using Xamarin.Forms;

namespace ShapesDemos
{
    public partial class PolylineDemoPage : ContentPage
    {
        public PolylineDemoPage()
        {
            InitializeComponent();
        }
    }
}
