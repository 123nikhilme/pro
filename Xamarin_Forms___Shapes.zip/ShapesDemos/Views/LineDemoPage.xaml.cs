﻿using Xamarin.Forms;

namespace ShapesDemos
{
    public partial class LineDemoPage : ContentPage
    {
        public LineDemoPage()
        {
            InitializeComponent();
        }
    }
}
