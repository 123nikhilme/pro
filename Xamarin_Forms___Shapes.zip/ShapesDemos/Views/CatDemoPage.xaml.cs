﻿using Xamarin.Forms;

namespace ShapesDemos
{
    public partial class CatDemoPage : ContentPage
    {
        public CatDemoPage()
        {
            InitializeComponent();
        }
    }
}
