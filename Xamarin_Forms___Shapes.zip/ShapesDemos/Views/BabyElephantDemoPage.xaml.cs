﻿using Xamarin.Forms;

namespace ShapesDemos
{
    public partial class BabyElephantDemoPage : ContentPage
    {
        public BabyElephantDemoPage()
        {
            InitializeComponent();
        }
    }
}
