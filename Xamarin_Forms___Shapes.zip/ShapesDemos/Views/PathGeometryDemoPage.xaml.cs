﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace ShapesDemos
{
    public partial class PathGeometryDemoPage : ContentPage
    {
        public PathGeometryDemoPage()
        {
            InitializeComponent();
        }
    }
}
