﻿using Xamarin.Forms;

namespace ShapesDemos
{
    public partial class InvertedXamagonDemoPage : ContentPage
    {
        public InvertedXamagonDemoPage()
        {
            InitializeComponent();
        }
    }
}
