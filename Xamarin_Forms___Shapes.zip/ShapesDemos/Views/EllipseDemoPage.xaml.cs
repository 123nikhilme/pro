﻿using Xamarin.Forms;

namespace ShapesDemos
{
    public partial class EllipseDemoPage : ContentPage
    {
        public EllipseDemoPage()
        {
            InitializeComponent();
        }
    }
}
