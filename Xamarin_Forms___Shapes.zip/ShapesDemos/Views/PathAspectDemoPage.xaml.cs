﻿using Xamarin.Forms;

namespace ShapesDemos
{
    public partial class PathAspectDemoPage : ContentPage
    {
        public PathAspectDemoPage()
        {
            InitializeComponent();
        }
    }
}
