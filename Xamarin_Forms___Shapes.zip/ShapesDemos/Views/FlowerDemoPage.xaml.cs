﻿using Xamarin.Forms;

namespace ShapesDemos
{
    public partial class FlowerDemoPage : ContentPage
    {
        public FlowerDemoPage()
        {
            InitializeComponent();
        }
    }
}
