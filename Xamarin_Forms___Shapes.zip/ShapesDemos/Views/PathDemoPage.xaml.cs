﻿using Xamarin.Forms;

namespace ShapesDemos
{
    public partial class PathDemoPage : ContentPage
    {
        public PathDemoPage()
        {
            InitializeComponent();
        }
    }
}
