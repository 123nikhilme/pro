﻿using Xamarin.Forms;

namespace ShapesDemos
{
    public partial class PathRenderTransformExamplesDemoPage : ContentPage
    {
        public PathRenderTransformExamplesDemoPage()
        {
            InitializeComponent();
        }
    }
}
