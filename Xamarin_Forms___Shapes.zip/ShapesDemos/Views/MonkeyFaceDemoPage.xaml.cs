﻿using Xamarin.Forms;

namespace ShapesDemos
{
    public partial class MonkeyFaceDemoPage : ContentPage
    {
        public MonkeyFaceDemoPage()
        {
            InitializeComponent();
        }
    }
}
