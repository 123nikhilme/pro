﻿using Xamarin.Forms;

namespace ShapesDemos
{
    public partial class PathRenderTransformDemoPage : ContentPage
    {
        public PathRenderTransformDemoPage()
        {
            InitializeComponent();
        }
    }
}
