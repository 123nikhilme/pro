﻿using Xamarin.Forms;

namespace ShapesDemos
{
    public partial class ClipArtManDemoPage : ContentPage
    {
        public ClipArtManDemoPage()
        {
            InitializeComponent();
        }
    }
}
