﻿using Xamarin.Forms;

namespace ShapesDemos
{
    public partial class ClipDemoPage : ContentPage
    {
        public ClipDemoPage()
        {
            InitializeComponent();
        }
    }
}
