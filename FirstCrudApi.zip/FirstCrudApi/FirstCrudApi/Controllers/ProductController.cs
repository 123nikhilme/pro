﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using FirstCrudApi.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FirstCrudApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ProductController : ControllerBase
    {
        static readonly IProductRepository repository = new ProductRepository();

        [Route("GetAllProducts")]
        [HttpGet]
        public IEnumerable<Product> GetAllProducts()
        {
            return repository.GetAll();


        }
        [Route("GetProduct")]
        [HttpGet]
        public ActionResult<Product> GetProduct(int id)
        {
            Product item = repository.Get(id);
            if (item == null)
            {
                return NotFound();
            }
            return item;
        }
        [Route("PostProduct")]
        [HttpPost]
        public Product PostProduct(Product item)
        {
            item = repository.Add(item);
            return item;
        }



    }

}
