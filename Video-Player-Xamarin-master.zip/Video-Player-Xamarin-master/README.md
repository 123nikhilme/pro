# Video-Player-Xamarin
A sample app for demoing playing a video on Xamarin Forms apps
