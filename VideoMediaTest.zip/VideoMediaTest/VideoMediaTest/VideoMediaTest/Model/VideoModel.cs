﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VideoMediaTest.Model
{
    public class VideoModel
    {
        public double id { get; set; }
        public string video_url { get; set; }
        public double video_height { get; set; }
    }
}
