﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VideoMediaTest.ViewModel;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace VideoMediaTest.View
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class VideoPage : ContentPage
    {
        VideoViewModel viewModel;
        public VideoPage()
        {
            try
            {
                InitializeComponent();
                this.SizeChanged += MainView_SizeChanged;
            }
            catch (Exception ex)
            {
            }
        }

        private void MainView_SizeChanged(object sender, System.EventArgs e)
        {
            try
            {
                ContentPage btn = sender as ContentPage;
                BindingContext = viewModel = new VideoViewModel(btn.Height);
            }
            catch (Exception ex)
            {
            }
        }
    }
}