﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VideoMediaTest.Model;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace VideoMediaTest.View
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CustomCellPage : Grid
    {
        public CustomCellPage()
        {
            InitializeComponent();
        }

        protected override void OnBindingContextChanged()
        {
            try
            {
                //imge1.CacheType = FFImageLoading.Cache.CacheType.All;
                //imge1.ca
               
                var item = BindingContext as VideoModel;

                if (item == null)
                {
                    return;
                }
                video.FlowDirection = FlowDirection.MatchParent;
                video.Shuffle = MediaManager.Queue.ShuffleMode.Off;
                //imge1.Source = item.ProductImage;
                video.Source = item.video_url;
                //video.ClassId= item.id;
                video.HeightRequest= item.video_height;
                base.OnBindingContextChanged();
            }
            catch (Exception ex)
            {
            }
        }
    }
}