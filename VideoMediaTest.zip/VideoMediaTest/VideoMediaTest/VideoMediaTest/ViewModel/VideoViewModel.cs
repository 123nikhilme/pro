﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using VideoMediaTest.Model;

namespace VideoMediaTest.ViewModel
{
    public class VideoViewModel : BaseViewModel
    {
        public VideoViewModel(double height)
        {
            video_list = new ObservableCollection<VideoModel>
            {
                new VideoModel
                {
                    id = 1,
                    video_url ="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                    video_height= height,
                },
                new VideoModel
                {
                    id = 2,
                    video_url ="http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
                    video_height= height,
                },
                new VideoModel
                {
                    id = 2,
                    video_url ="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
                    video_height= height,
                },
            };
        }

        private ObservableCollection<VideoModel> _video_list;
        public ObservableCollection<VideoModel> video_list
        {
            get { return _video_list; }
            set
            {
                _video_list = value;
                OnPropertyChanged("video_list");
            }
        }
    }
}
