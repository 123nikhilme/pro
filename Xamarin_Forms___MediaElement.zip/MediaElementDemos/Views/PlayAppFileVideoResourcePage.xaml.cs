﻿using Xamarin.Forms;

namespace MediaElementDemos
{
    public partial class PlayAppFileVideoResourcePage : ContentPage
    {
        public PlayAppFileVideoResourcePage()
        {
            InitializeComponent();
        }
    }
}
