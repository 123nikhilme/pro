﻿using Xamarin.Forms;

namespace MediaElementDemos
{
    public partial class PlayAppPackageVideoResourcePage : ContentPage
    {
        public PlayAppPackageVideoResourcePage()
        {
            InitializeComponent();
        }
    }
}
