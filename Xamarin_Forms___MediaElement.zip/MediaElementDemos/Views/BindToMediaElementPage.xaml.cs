﻿using Xamarin.Forms;

namespace MediaElementDemos
{
    public partial class BindToMediaElementPage : ContentPage
    {
        public BindToMediaElementPage()
        {
            InitializeComponent();
        }
    }
}
