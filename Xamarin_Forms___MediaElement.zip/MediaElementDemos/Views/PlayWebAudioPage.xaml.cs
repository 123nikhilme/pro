﻿using Xamarin.Forms;

namespace MediaElementDemos
{
    public partial class PlayWebAudioPage : ContentPage
    {
        public PlayWebAudioPage()
        {
            InitializeComponent();
        }
    }
}
