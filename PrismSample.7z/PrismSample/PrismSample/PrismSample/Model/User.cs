﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PrismSample.Model
{
    public class User
    {
        public string UserName { get; set; }
        public string Age { get; set; }
        public string Salary { get; set; }
        public string Location { get; set; }
    }
}
