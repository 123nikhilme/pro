﻿using Prism;
using Prism.Ioc;
using Prism.Unity;
using PrismSample.ViewModel;
using PrismSample.Views;
using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace PrismSample
{
    public partial class App : PrismApplication
    {
        public App(IPlatformInitializer platformInitializer) : base(platformInitializer)
        {
        }

        protected override void OnStart()
        {
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {
        }

        protected override void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.RegisterForNavigation<HomePage, HomePageViewModel>();
        }

        protected override void OnInitialized()
        {
            InitializeComponent();
            NavigationService.NavigateAsync("HomePage");
        }
    }
}
