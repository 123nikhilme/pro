﻿using Prism.Mvvm;
using Prism.Navigation;
using PrismSample.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace PrismSample.ViewModel
{
    public class HomePageViewModel : BindableBase, IInitialize
    {
        private ObservableCollection<User> users;
        public ObservableCollection<User> Users
        {
            get
            {
                return users;
            }
            set
            {
                SetProperty(ref users, value);
            }
        }

        private readonly INavigationService navigationService;
        public HomePageViewModel(INavigationService navigationService)
        {
            this.navigationService = navigationService;
        }

        public void Initialize(INavigationParameters parameters)
        {
            Users = new ObservableCollection<User>();
            Users.Add(new User() { UserName = "Hari", Age = "25", Salary = "10000", Location = "Hyderabad" });
            Users.Add(new User() { UserName = "Hari1", Age = "25", Salary = "10000", Location = "Hyderabad" });
            Users.Add(new User() { UserName = "Hari2", Age = "25", Salary = "10000", Location = "Hyderabad" });
            Users.Add(new User() { UserName = "Hari3", Age = "25", Salary = "10000", Location = "Hyderabad" });
            Users.Add(new User() { UserName = "Hari4", Age = "25", Salary = "10000", Location = "Hyderabad" });
            Users.Add(new User() { UserName = "Hari4", Age = "25", Salary = "10000", Location = "Hyderabad" });
            Users.Add(new User() { UserName = "Hari5", Age = "25", Salary = "10000", Location = "Hyderabad" });
            Users.Add(new User() { UserName = "Hari6", Age = "25", Salary = "10000", Location = "Hyderabad" });
        }
    }
}
