﻿using Xamarin.Forms;

namespace WorkingWithMaps
{
    public partial class PolygonsPage : ContentPage
    {
        public PolygonsPage()
        {
            InitializeComponent();
        }
    }
}