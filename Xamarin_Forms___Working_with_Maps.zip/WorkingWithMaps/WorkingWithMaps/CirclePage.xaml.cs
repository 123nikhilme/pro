﻿using Xamarin.Forms;

namespace WorkingWithMaps
{
    public partial class CirclePage : ContentPage
    {
        public CirclePage()
        {
            InitializeComponent();
        }
    }
}
