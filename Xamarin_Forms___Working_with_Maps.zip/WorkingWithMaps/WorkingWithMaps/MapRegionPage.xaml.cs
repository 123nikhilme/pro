﻿using Xamarin.Forms;

namespace WorkingWithMaps
{
    public partial class MapRegionPage : ContentPage
    {
        public MapRegionPage()
        {
            InitializeComponent();
        }
    }
}


