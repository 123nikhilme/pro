﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace CollectionViewDemos.Views
{
    public partial class HorizontalListTextPage : ContentPage
    {
        public HorizontalListTextPage()
        {
            InitializeComponent();
        }
    }
}
