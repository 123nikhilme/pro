﻿using CollectionViewDemos.ViewModels;
using Xamarin.Forms;

namespace CollectionViewDemos.Views
{
    public partial class VerticalListTextPage : ContentPage
    {
        public VerticalListTextPage()
        {
            InitializeComponent();
        }
    }
}
