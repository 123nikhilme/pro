﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace CollectionViewDemos.Views
{
    public partial class HorizontalGridTextPage : ContentPage
    {
        public HorizontalGridTextPage()
        {
            InitializeComponent();
        }
    }
}
