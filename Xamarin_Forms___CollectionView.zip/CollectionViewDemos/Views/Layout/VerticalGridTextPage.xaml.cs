﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace CollectionViewDemos.Views
{
    public partial class VerticalGridTextPage : ContentPage
    {
        public VerticalGridTextPage()
        {
            InitializeComponent();
        }
    }
}
