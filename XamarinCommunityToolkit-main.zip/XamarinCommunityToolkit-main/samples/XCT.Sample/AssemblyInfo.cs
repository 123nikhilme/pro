﻿using System.Resources;
using Xamarin.Forms;
using Xamarin.Forms.Internals;
using Xamarin.Forms.Xaml;

[assembly: XamlCompilation(XamlCompilationOptions.Compile)]
[assembly: Preserve(AllMembers = true)]
[assembly: NeutralResourcesLanguage("en")]
[assembly: ExportFont("Font Awesome 5 Free-Regular-400.otf", Alias = "FARegular")]