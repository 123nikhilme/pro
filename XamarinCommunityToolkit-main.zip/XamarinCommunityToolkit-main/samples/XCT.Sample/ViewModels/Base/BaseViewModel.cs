﻿using Xamarin.CommunityToolkit.ObjectModel;

namespace Xamarin.CommunityToolkit.Sample.ViewModels
{
	public abstract class BaseViewModel : ObservableObject
	{
	}
}