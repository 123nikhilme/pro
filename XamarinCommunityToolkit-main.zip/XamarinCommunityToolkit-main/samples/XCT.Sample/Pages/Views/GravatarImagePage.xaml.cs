﻿namespace Xamarin.CommunityToolkit.Sample.Pages.Views
{
	public partial class GravatarImagePage : BasePage
	{
		public GravatarImagePage() =>
			InitializeComponent();
	}
}