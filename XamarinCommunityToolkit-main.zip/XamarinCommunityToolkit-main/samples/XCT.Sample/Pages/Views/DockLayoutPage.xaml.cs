﻿namespace Xamarin.CommunityToolkit.Sample.Pages.Views
{
	public partial class DockLayoutPage
	{
		public DockLayoutPage()
			=> InitializeComponent();
	}
}