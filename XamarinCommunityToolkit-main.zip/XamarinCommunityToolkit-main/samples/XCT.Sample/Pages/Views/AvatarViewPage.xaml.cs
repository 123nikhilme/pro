﻿namespace Xamarin.CommunityToolkit.Sample.Pages.Views
{
	public partial class AvatarViewPage : BasePage
	{
		public AvatarViewPage()
			=> InitializeComponent();
	}
}