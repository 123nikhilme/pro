﻿namespace Xamarin.CommunityToolkit.Sample.Pages.Views
{
	public partial class ExpanderPage
	{
		public ExpanderPage()
			=> InitializeComponent();
	}
}