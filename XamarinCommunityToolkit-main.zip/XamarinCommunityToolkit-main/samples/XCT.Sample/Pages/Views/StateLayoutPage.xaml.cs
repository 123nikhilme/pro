﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Xamarin.CommunityToolkit.Sample.Pages.Views
{
	public partial class StateLayoutPage : BasePage
	{
		public StateLayoutPage()
			=> InitializeComponent();
	}
}