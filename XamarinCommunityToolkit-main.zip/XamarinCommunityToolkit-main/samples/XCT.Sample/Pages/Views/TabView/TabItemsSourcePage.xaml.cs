﻿namespace Xamarin.CommunityToolkit.Sample.Pages.Views.TabView
{
	public partial class TabItemsSourcePage : BasePage
	{
		public TabItemsSourcePage() => InitializeComponent();
	}
}