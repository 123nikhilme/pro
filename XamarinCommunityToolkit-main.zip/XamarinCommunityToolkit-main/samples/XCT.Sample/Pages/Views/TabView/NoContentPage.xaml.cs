﻿namespace Xamarin.CommunityToolkit.Sample.Pages.Views.TabView
{
	public partial class NoContentPage : BasePage
	{
		public NoContentPage() => InitializeComponent();
	}
}