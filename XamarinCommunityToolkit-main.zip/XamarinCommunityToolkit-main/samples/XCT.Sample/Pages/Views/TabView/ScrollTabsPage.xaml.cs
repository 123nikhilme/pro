﻿namespace Xamarin.CommunityToolkit.Sample.Pages.Views.TabView
{
	public partial class ScrollTabsPage : BasePage
	{
		public ScrollTabsPage() => InitializeComponent();
	}
}