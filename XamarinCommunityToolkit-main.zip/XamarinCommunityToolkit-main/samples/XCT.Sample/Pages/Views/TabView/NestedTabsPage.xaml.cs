﻿namespace Xamarin.CommunityToolkit.Sample.Pages.Views.TabView
{
	public partial class NestedTabsPage : BasePage
	{
		public NestedTabsPage() => InitializeComponent();
	}
}