﻿namespace Xamarin.CommunityToolkit.Sample.Pages.Views.TabView
{
	public partial class IsTabStripVisiblePage : BasePage
	{
		public IsTabStripVisiblePage() => InitializeComponent();
	}
}