﻿namespace Xamarin.CommunityToolkit.Sample.Pages.Views.TabView
{
	public partial class GettingStartedPage : BasePage
	{
		public GettingStartedPage() => InitializeComponent();
	}
}