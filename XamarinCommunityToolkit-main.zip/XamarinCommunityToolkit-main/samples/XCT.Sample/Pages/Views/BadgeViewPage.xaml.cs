﻿using Xamarin.Forms;

namespace Xamarin.CommunityToolkit.Sample.Pages.Views
{
	public partial class BadgeViewPage : BasePage
	{
		public BadgeViewPage() => InitializeComponent();
	}
}