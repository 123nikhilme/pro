﻿namespace Xamarin.CommunityToolkit.Sample.Pages.Views
{
	public partial class ViewsGalleryPage : BasePage
	{
		public ViewsGalleryPage()
			=> InitializeComponent();
	}
}