﻿namespace Xamarin.CommunityToolkit.Sample.Pages.Converters
{
	public partial class ItemTappedEventArgsPage : BasePage
	{
		public ItemTappedEventArgsPage()
			=> InitializeComponent();
	}
}