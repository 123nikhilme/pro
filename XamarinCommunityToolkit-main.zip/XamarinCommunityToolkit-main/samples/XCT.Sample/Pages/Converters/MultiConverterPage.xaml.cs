﻿namespace Xamarin.CommunityToolkit.Sample.Pages.Converters
{
	public partial class MultiConverterPage
	{
		public MultiConverterPage()
			=> InitializeComponent();
	}
}