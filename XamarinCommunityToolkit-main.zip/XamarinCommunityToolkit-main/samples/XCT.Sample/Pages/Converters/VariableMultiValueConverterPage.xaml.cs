﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Xamarin.CommunityToolkit.Sample.Pages.Converters
{
	public partial class VariableMultiValueConverterPage
	{
		public VariableMultiValueConverterPage()
		{
			InitializeComponent();
		}
	}
}
