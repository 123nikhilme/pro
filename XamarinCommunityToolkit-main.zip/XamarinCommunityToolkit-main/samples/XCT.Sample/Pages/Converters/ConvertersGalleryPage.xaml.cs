﻿namespace Xamarin.CommunityToolkit.Sample.Pages.Converters
{
	public partial class ConvertersGalleryPage : BasePage
	{
		public ConvertersGalleryPage()
			=> InitializeComponent();
	}
}