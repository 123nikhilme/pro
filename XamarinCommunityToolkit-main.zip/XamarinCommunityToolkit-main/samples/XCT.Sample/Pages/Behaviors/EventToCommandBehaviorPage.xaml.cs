﻿namespace Xamarin.CommunityToolkit.Sample.Pages.Behaviors
{
	public partial class EventToCommandBehaviorPage : BasePage
	{
		public EventToCommandBehaviorPage()
			=> InitializeComponent();
	}
}