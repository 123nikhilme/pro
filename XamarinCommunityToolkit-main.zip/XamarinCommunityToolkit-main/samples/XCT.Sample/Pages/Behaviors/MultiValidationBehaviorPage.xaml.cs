﻿namespace Xamarin.CommunityToolkit.Sample.Pages.Behaviors
{
	public partial class MultiValidationBehaviorPage
	{
		public MultiValidationBehaviorPage()
			=> InitializeComponent();
	}
}