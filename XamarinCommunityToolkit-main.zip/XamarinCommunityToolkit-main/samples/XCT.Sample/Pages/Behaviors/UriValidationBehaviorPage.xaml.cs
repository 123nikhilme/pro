﻿namespace Xamarin.CommunityToolkit.Sample.Pages.Behaviors
{
	public partial class UriValidationBehaviorPage
	{
		public UriValidationBehaviorPage()
			=> InitializeComponent();
	}
}