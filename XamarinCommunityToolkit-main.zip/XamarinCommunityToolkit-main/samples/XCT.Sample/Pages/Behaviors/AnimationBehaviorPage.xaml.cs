﻿namespace Xamarin.CommunityToolkit.Sample.Pages.Behaviors
{
	public partial class AnimationBehaviorPage : BasePage
	{
		public AnimationBehaviorPage()
			=> InitializeComponent();
	}
}