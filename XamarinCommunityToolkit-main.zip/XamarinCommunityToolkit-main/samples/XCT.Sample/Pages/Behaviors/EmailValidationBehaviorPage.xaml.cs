﻿namespace Xamarin.CommunityToolkit.Sample.Pages.Behaviors
{
	public partial class EmailValidationBehaviorPage : BasePage
	{
		public EmailValidationBehaviorPage()
			=> InitializeComponent();
	}
}