﻿namespace Xamarin.CommunityToolkit.Sample.Pages.Behaviors
{
	public partial class NumericValidationBehaviorPage : BasePage
	{
		public NumericValidationBehaviorPage()
			=> InitializeComponent();
	}
}