﻿namespace Xamarin.CommunityToolkit.Sample.Pages.Behaviors
{
	public partial class BehaviorsGalleryPage : BasePage
	{
		public BehaviorsGalleryPage()
			=> InitializeComponent();
	}
}