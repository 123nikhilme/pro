﻿namespace Xamarin.CommunityToolkit.Sample.Pages.Behaviors
{
	public partial class MaskedBehaviorPage : BasePage
	{
		public MaskedBehaviorPage()
			=> InitializeComponent();
	}
}