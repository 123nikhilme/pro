﻿namespace Xamarin.CommunityToolkit.Sample.Pages.Extensions
{
	public partial class ExtensionsGalleryPage : BasePage
	{
		public ExtensionsGalleryPage()
			=> InitializeComponent();
	}
}