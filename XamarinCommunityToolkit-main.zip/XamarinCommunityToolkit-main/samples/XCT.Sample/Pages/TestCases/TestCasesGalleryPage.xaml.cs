﻿namespace Xamarin.CommunityToolkit.Sample.Pages.TestCases
{
	public partial class TestCasesGalleryPage : BasePage
	{
		public TestCasesGalleryPage()
			=> InitializeComponent();
	}
}