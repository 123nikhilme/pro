﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Xamarin.CommunityToolkit.Markup.UnitTests")]