﻿using Xamarin.CommunityToolkit.UI.Views;
using Xamarin.Forms;

[assembly: ExportImageSourceHandler(typeof(GravatarImageSource), typeof(GravatarImageSourceHandler))]