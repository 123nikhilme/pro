using Xamarin.CommunityToolkit.UI.Views;
using Xamarin.Forms.Platform.WPF;

[assembly: ExportImageSourceHandler(typeof(GravatarImageSource), typeof(GravatarImageSourceHandler))]