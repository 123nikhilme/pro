﻿using Xamarin.CommunityToolkit.UI.Views;
using Xamarin.Forms.Platform.UWP;

[assembly: ExportImageSourceHandler(typeof(GravatarImageSource), typeof(GravatarImageSourceHandler))]