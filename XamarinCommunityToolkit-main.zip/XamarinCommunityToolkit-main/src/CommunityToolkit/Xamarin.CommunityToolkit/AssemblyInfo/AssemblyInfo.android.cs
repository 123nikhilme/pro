﻿using Android;
using Xamarin.CommunityToolkit.UI.Views;
using Xamarin.Forms;

[assembly: LinkerSafe]

[assembly: ExportImageSourceHandler(typeof(GravatarImageSource), typeof(GravatarImageSourceHandler))]