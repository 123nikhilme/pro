﻿namespace Xamarin.CommunityToolkit.Effects
{
	public enum HoverStatus
	{
		Entered,
		Exited
	}
}
