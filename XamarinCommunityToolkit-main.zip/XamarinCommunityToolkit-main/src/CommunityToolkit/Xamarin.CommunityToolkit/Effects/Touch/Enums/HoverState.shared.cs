﻿namespace Xamarin.CommunityToolkit.Effects
{
	public enum HoverState
	{
		Normal,
		Hovered
	}
}
