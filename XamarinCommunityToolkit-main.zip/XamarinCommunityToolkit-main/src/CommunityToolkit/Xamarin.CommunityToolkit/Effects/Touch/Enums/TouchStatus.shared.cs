﻿namespace Xamarin.CommunityToolkit.Effects
{
	public enum TouchStatus
	{
		Started,
		Completed,
		Canceled
	}
}
