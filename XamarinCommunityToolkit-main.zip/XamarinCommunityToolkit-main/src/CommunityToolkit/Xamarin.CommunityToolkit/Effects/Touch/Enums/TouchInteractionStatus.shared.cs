﻿namespace Xamarin.CommunityToolkit.Effects
{
	public enum TouchInteractionStatus
	{
		Started,
		Completed
	}
}
