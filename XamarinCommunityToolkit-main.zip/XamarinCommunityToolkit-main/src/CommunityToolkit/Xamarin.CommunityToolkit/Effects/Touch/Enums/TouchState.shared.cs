﻿namespace Xamarin.CommunityToolkit.Effects
{
	public enum TouchState
	{
		Normal,
		Pressed
	}
}
