﻿namespace Xamarin.CommunityToolkit.UI.Views
{
	public enum BadgePosition
	{
		TopLeft,
		TopRight,
		BottomLeft,
		BottomRight
	}
}