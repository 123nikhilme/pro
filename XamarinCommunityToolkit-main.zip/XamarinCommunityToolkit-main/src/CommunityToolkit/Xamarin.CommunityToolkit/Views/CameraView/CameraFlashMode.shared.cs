﻿namespace Xamarin.CommunityToolkit.UI.Views
{
	public enum CameraFlashMode
	{
		Off,
		On,
		Auto,
		Torch
	}
}