﻿namespace Xamarin.CommunityToolkit.UI.Views
{
	public enum CameraOptions
	{
		Default,
		Front,
		Back,
		External
	}
}