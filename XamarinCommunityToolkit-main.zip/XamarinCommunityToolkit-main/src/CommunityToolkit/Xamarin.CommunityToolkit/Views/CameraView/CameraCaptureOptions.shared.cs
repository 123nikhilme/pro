﻿namespace Xamarin.CommunityToolkit.UI.Views
{
	public enum CameraCaptureMode
	{
		Default,
		Photo,
		Video
	}
}