﻿namespace Xamarin.CommunityToolkit.UI.Views
{
    public enum Dock
    {
        Left,
        Top,
        Right,
        Bottom
    }
}