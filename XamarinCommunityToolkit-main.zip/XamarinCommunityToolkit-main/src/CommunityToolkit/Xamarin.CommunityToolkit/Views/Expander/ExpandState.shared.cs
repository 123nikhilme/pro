﻿namespace Xamarin.CommunityToolkit.UI.Views
{
	public enum ExpandState
	{
		Expanding,
		Expanded,
		Collapsing,
		Collapsed
	}
}