﻿namespace Xamarin.CommunityToolkit.UI.Views
{
	public enum ExpandDirection
	{
		Down,
		Up,
		Left,
		Right
	}
}