﻿namespace Xamarin.CommunityToolkit.UI.Views
{
	public enum TabStripPlacement
	{
		Top,
		Bottom
	}
}