﻿namespace Xamarin.CommunityToolkit.UI.Views
{
	public enum TabIndicatorPlacement
	{
		Top,
		Center,
		Bottom
	}
}