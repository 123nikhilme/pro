﻿namespace Xamarin.CommunityToolkit.UI.Views
{
	public enum SideMenuPosition
	{
		LeftMenu = -1,
		MainView = 0,
		RightMenu = 1
	}
}