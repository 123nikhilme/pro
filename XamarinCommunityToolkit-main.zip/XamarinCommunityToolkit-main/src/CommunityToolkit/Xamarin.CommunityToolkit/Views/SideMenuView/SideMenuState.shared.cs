﻿namespace Xamarin.CommunityToolkit.UI.Views
{
	public enum SideMenuState
	{
		LeftMenuShown = -1,
		MainViewShown = 0,
		RightMenuShown = 1
	}
}