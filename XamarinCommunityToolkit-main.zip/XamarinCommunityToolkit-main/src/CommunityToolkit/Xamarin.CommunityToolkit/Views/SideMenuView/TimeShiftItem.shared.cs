﻿using System;

namespace Xamarin.CommunityToolkit.UI.Views
{
	struct TimeShiftItem
	{
		public DateTime Time { get; set; }

		public double Shift { get; set; }
	}
}