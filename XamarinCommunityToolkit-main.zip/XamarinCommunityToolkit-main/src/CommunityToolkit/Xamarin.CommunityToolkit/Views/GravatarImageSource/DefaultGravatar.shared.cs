﻿namespace Xamarin.CommunityToolkit.UI.Views
{
	public enum DefaultGravatar
	{
		FileNotFound,
		MysteryPerson,
		Identicon,
		MonsterId,
		Wavatar,
		Retro,
		Robohash,
		Blank
	}
}