﻿namespace Xamarin.CommunityToolkit.Helpers
{
	public enum MultiBindingCondition
	{
		None,
		All,
		Any,
		Exact,
		GreaterThan,
		LessThan
	}
}
