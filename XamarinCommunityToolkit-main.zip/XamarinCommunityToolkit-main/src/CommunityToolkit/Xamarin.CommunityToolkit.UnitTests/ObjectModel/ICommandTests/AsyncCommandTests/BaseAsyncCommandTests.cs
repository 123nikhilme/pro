﻿namespace Xamarin.CommunityToolkit.UnitTests.ObjectModel.ICommandTests.AsyncCommandTests
{
	public abstract class BaseAsyncCommandTests : BaseCommandTests
	{
	}
}