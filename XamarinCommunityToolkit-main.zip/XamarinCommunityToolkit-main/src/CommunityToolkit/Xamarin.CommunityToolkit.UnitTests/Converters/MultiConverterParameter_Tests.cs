﻿using System;
namespace Xamarin.CommunityToolkit.UnitTests.Converters
{
	public class MultiConverterParameter_Tests
	{
		public MultiConverterParameter_Tests()
		{
		}
	}
}