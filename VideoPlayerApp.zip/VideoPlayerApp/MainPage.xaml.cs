﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Plugin.MediaManager.Forms;
using Plugin.MediaManager;
using Plugin.MediaManager.Abstractions.Enums;

namespace VideoPlayerApp
{
	public partial class MainPage : ContentPage
	{
        private string videoUrl = "https://sec.ch9.ms/ch9/e68c/690eebb1-797a-40ef-a841-c63dded4e68c/Cognitive-Services-Emotion_high.mp4";
		public MainPage()
		{
			InitializeComponent();
		}

        
        private void PlayStopButton(object sender,EventArgs e)
        {
            if (PlayStopButtonText.Text == "Play")
            {
                CrossMediaManager.Current.Play(videoUrl, MediaFileType.Video);

                PlayStopButtonText.Text = "Stop";
            }
            else if (PlayStopButtonText.Text == "Stop")
            {
                CrossMediaManager.Current.Play(videoUrl, MediaFileType.Video);

                PlayStopButtonText.Text = "Play";
            }
        }
    }
}
