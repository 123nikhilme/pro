﻿using System;
using Xamarin.Forms;

namespace DualScreenDemos
{
    public class HingeAngleLabel : Label { }
}
