---
name: Xamarin.Forms - IndicatorView
description: "This sample demonstrates how to use the Xamarin.Forms IndicatorView (UI)"
page_type: sample
languages:
- csharp
products:
- xamarin
extensions:
    tags:
    - ui
urlFragment: userinterface-indicatorviewdemos
---
# IndicatorView

This sample demonstrates how to use the Xamarin.Forms `IndicatorView`.

For more information about this sample, see [Xamarin.Forms IndicatorView](https://docs.microsoft.com/xamarin/xamarin-forms/user-interface/indicatorview/).

![IndicatorView application screenshot](Screenshots/01All.png "IndicatorView application screenshot")

