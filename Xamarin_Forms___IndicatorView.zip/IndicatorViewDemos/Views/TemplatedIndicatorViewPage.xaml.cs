﻿using Xamarin.Forms;

namespace IndicatorViewDemos.Views
{
    public partial class TemplatedIndicatorViewPage : ContentPage
    {
        public TemplatedIndicatorViewPage()
        {
            InitializeComponent();
        }
    }
}
