﻿using Xamarin.Forms;

namespace IndicatorViewDemos.Views
{
    public partial class BasicIndicatorViewPage : ContentPage
    {
        public BasicIndicatorViewPage()
        {
            InitializeComponent();
        }
    }
}
